//user 用户端
//vue-admin-template-master 管理员端

//  删除node_modules  前端初始化
1. 安装cnpm ：`npm install cnpm -g`
2. 安装 node-sass： `cnpm install node-sass`
3. 继续安装 : `cnpm i node-sass -D`
4. 根据package.json安装依赖：`cnpm install`
5. 启动项目：`npm run dev`

//* 服务器重启后开 
/user/local/nginx/sbin ./nginx
docker start mysql
docker start my_redis

//部署到服务器  --> dist
//npm run build

//安装express-generator生成器
npm install express-generator -g 

//express user --> user public
dist --> user public

//前端推送服务器 /usr/local/user/userFront/public unzip
//nohup npm start & 
//enter exit

//后端jar包  /usr/local/user/userBehind   /usr/local/admin
//nohup java -Xms256m -Xmx256m -Xmn250m -Xss4m -jar shared_parking_space-0.0.1-SNAPSHOT.jar &
//enter exit
//查看配置java -jar   jps -v
